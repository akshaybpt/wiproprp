package inheretance;

  class Person {
	String name;
}
