package languageBasic;

public class CommandTwo {
	public static void main (String [] agrs) {
		int n=Integer.parseInt(agrs[0]);
		int m=Integer.parseInt(agrs[1]);
		System.out.println(n+m);
	}

}
