package languageBasic;

public class CommandOne {
public static void main(String agrs[]) {
	System.out.println(agrs[0]+" Technologies "+agrs[1]);
	
}
}
